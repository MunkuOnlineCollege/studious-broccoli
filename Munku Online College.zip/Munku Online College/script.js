document.addEventListener('DOMContentLoaded', () => {
    // JavaScript code can be added here if needed
});
